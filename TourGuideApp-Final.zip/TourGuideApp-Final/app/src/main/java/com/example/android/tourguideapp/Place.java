package com.example.android.tourguideapp;


public class Place {
    private String placeTitle;
    private String placeSubtitle;
    private String descInfo;
    private int imageResourceID = -1;

    public Place(String firstTextInput, String SecondTextInput) {
        placeTitle = firstTextInput;
        placeSubtitle = SecondTextInput;
    }

    public Place(String firstTextInput, String SecondTextInput, int itemImageInput) {
        placeTitle = firstTextInput;
        placeSubtitle = SecondTextInput;
        imageResourceID = itemImageInput;
    }

    public Place(String firstTextInput, String SecondTextInput, String ThirdTextInput, int itemImageInput) {
        placeTitle = firstTextInput;
        placeSubtitle = SecondTextInput;
        descInfo = ThirdTextInput;
        imageResourceID = itemImageInput;
    }

    public void setWord(String SecondTextInput) {
        placeSubtitle = SecondTextInput;
    }

    public void setDesc(String ThirdTextInput) {
        descInfo = ThirdTextInput;
    }

    public String getPlaceTitle() {
        return placeTitle;
    }

    public void setPlaceTitle(String firstTextInput) {
        placeTitle = firstTextInput;
    }

    public String getPlaceSubtitle() {
        return placeSubtitle;
    }

    public String getPlaceDesc() {
        return descInfo;
    }

    public int getItemImage() {
        return imageResourceID;
    }

    public void setItemImage(int itemImageInput) {
        imageResourceID = itemImageInput;
    }

    public boolean hasImage() {
        return imageResourceID != -1;
    }
}

