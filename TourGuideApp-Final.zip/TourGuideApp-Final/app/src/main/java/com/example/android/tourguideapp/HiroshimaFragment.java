package com.example.android.tourguideapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class HiroshimaFragment extends Fragment {

    public HiroshimaFragment() {
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.word_list, container, false);
        final ArrayList<Place> places = new ArrayList<>();
        places.add(new Place(getString(R.string.hiro_1), getString(R.string.hiro_11), getString(R.string.hiro_111),
                R.drawable.h1));
        places.add(new Place(getString(R.string.hiro_2), getString(R.string.hiro_22), getString(R.string.hiro_222),
                R.drawable.h2));
        places.add(new Place(getString(R.string.hiro_3), getString(R.string.hiro_33), getString(R.string.hiro_333),
                R.drawable.h3));
        places.add(new Place(getString(R.string.hiro_4), getString(R.string.hiro_44), getString(R.string.hiro_4444),
                R.drawable.h4));
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Class myActivityToIntent = PlaceInfoViewer.class;
                Intent myIntent = new Intent(getActivity().getApplicationContext(), myActivityToIntent);
                myIntent.putExtra(getString(R.string.myTitle), places.get(i).getPlaceTitle());
                myIntent.putExtra(getString(R.string.mySubTitle), places.get(i).getPlaceSubtitle());
                myIntent.putExtra(getString(R.string.myDesc), places.get(i).getPlaceDesc());
                myIntent.putExtra(getString(R.string.myImg), places.get(i).getItemImage());
                startActivity(myIntent);

            }
        });
        return rootView;
    }

}
