package com.example.android.tourguideapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.support.v4.app.Fragment;

import java.util.ArrayList;


public class TokyoFragment extends Fragment {
    public TokyoFragment() {
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        final ArrayList<Place> places = new ArrayList<Place>();
        places.add(new Place(getString(R.string.tokyo_1), getString(R.string.tokyo_fg), getString(R.string.tokyo_f),
                R.drawable.t1));
        places.add(new Place(getString(R.string.tokyo_2), getString(R.string.tokyodd), getString(R.string.tokyo_e) +
                getString(R.string.tokyo_dbrd),
                R.drawable.t2));
        places.add(new Place(getString(R.string.tokyo_3), getString(R.string.tokyo_mm), getString(R.string.tokyo_eee),
                R.drawable.t3));
        places.add(new Place(getString(R.string.tokyo_4), getString(R.string.tokyo_mmmm), getString(R.string.tokyo_w3) +
                getString(R.string.tokyo_qwe) +
                getString(R.string.tokyo_nm),
                R.drawable.t4));
        places.add(new Place(getString(R.string.tokyo_5), getString(R.string.tokyo_4yh), getString(R.string.tokyo_tfjrty) +
                getString(R.string.tokyo_nhgfde),
                R.drawable.t5));
        places.add(new Place(getString(R.string.tokyo_6), getString(R.string.tokyo_hil), getString(R.string.tokyo_45tg),
                R.drawable.t6));
        places.add(new Place(getString(R.string.tokyo_7), getString(R.string.tokyo_57j76), getString(R.string.tokyo_get4egr),
                R.drawable.t7ueno));
        places.add(new Place(getString(R.string.tokyo_8), getString(R.string.tokyo_r45h5), getString(R.string.tokyo_r56yh),
                R.drawable.t8));
        places.add(new Place(getString(R.string.tokyo_9), getString(R.string.tokyo_45ret), getString(R.string.tokyo_y6k87),
                R.drawable.t9));
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Class myActivityToIntent = PlaceInfoViewer.class;

                Intent myIntent = new Intent(getActivity().getApplicationContext(), myActivityToIntent);
                myIntent.putExtra(getString(R.string.myTitle), places.get(i).getPlaceTitle());
                myIntent.putExtra(getString(R.string.mySubTitle), places.get(i).getPlaceSubtitle());
                myIntent.putExtra(getString(R.string.myDesc), places.get(i).getPlaceDesc());
                myIntent.putExtra(getString(R.string.myImg), places.get(i).getItemImage());

                startActivity(myIntent);

            }
        });
        return rootView;
    }

}

