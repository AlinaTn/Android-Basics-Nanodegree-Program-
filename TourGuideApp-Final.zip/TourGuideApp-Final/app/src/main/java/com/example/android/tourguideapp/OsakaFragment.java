package com.example.android.tourguideapp;

import android.content.Intent;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.support.v4.app.Fragment;

import java.util.ArrayList;

public class OsakaFragment extends Fragment {

    public OsakaFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        final ArrayList<Place> places = new ArrayList<>();
        places.add(new Place(getString(R.string.osaka_1), getString(R.string.osaka_11), getString(R.string.osaka_111),
                R.drawable.o1));
        places.add(new Place(getString(R.string.osaka_2), getString(R.string.osaka_22), getString(R.string.osaka_222),
                R.drawable.o2));
        places.add(new Place(getString(R.string.osaka_3), getString(R.string.osaka_33), getString(R.string.osaka_333) +
                "\n" +
                getString(R.string.osaka_3333),
                R.drawable.o3));
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Class myActivityToIntent = PlaceInfoViewer.class;
                Intent myIntent = new Intent(getActivity().getApplicationContext(), myActivityToIntent);
                myIntent.putExtra(getString(R.string.myTitle), places.get(i).getPlaceTitle());
                myIntent.putExtra(getString(R.string.mySubTitle), places.get(i).getPlaceSubtitle());
                myIntent.putExtra(getString(R.string.myDesc), places.get(i).getPlaceDesc());
                myIntent.putExtra(getString(R.string.myImg), places.get(i).getItemImage());
                startActivity(myIntent);
            }
        });
        return rootView;
    }

}
