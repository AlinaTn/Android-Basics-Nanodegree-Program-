package com.example.android.tourguideapp;

import android.content.Intent;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.support.v4.app.Fragment;

import java.util.ArrayList;

public class KyotoFragment extends Fragment {

    public KyotoFragment() {
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        final ArrayList<Place> places = new ArrayList<>();
        places.add(new Place(getString(R.string.kyoto_1), getString(R.string.kyoto_11), getString(R.string.kyoto_111),
                R.drawable.k1));
        places.add(new Place(getString(R.string.kyoto_2), getString(R.string.kyoto_22), getString(R.string.kyoto_222),
                R.drawable.k2));
        places.add(new Place(getString(R.string.kyoto_3), getString(R.string.kyoto_33), getString(R.string.kyoto_3333),
                R.drawable.k3));
        places.add(new Place(getString(R.string.kyoto_4), getString(R.string.kyoto_44), getString(R.string.kyoto_444),
                R.drawable.k4));
        places.add(new Place(getString(R.string.kyoto_5), getString(R.string.kyoto_55), getString(R.string.kyoto_555),
                R.drawable.k5));

        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Class myActivityToIntent = PlaceInfoViewer.class;
                Intent myIntent = new Intent(getActivity().getApplicationContext(), myActivityToIntent);
                myIntent.putExtra(getString(R.string.myTitle), places.get(i).getPlaceTitle());
                myIntent.putExtra(getString(R.string.mySubTitle), places.get(i).getPlaceSubtitle());
                myIntent.putExtra(getString(R.string.myDesc), places.get(i).getPlaceDesc());
                myIntent.putExtra(getString(R.string.myImg), places.get(i).getItemImage());
                startActivity(myIntent);

            }
        });
        return rootView;
    }

}

