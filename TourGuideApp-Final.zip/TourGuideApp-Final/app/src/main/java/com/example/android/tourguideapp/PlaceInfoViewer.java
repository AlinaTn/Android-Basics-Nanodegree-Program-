package com.example.android.tourguideapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;


public class PlaceInfoViewer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_info);

        String newString;
        String newStringForSub;
        String newStringforDesc;
        int newImg = 0;
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                newString = null;
                newStringForSub = null;
                newStringforDesc = null;
            } else {
                newString = extras.getString(getString(R.string.myTitle));
                newStringForSub = extras.getString(getString(R.string.mySubTitle));
                newStringforDesc = extras.getString(getString(R.string.myDesc));
                newImg = extras.getInt(getString(R.string.myImg));
            }
        } else {
            newString = (String) savedInstanceState.getSerializable(getString(R.string.string_i_need));
            newStringForSub = (String) savedInstanceState.getSerializable(getString(R.string.string_i_need));
            newStringforDesc = (String) savedInstanceState.getSerializable(getString(R.string.string_i_need));
        }
        ArrayList<Place> places = new ArrayList<>();
        places.add(new Place(newString, newStringForSub, newStringforDesc, newImg));
        PlaceViewerAdapter itemsAdapter = new PlaceViewerAdapter(this, places);


        ListView mylistView = findViewById(R.id.place_info);

        mylistView.setAdapter(itemsAdapter);

    }
}
