package com.example.android.tourguideapp;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


class PlaceViewerAdapter extends ArrayAdapter<Place> {
    private int viewBGColor;

    public PlaceViewerAdapter(Activity context, ArrayList<Place> Tunes) {
        super(context, 0, Tunes);
        viewBGColor = R.color.white_background;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;

        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.place_info_list_item, parent, false);
        }
        Place currentPlace = getItem(position);
        TextView titleTextView = listItemView.findViewById(R.id.listItemName);
        titleTextView.setText(currentPlace.getPlaceTitle());
        TextView subtitleTextView = listItemView.findViewById(R.id.listItemDesc);
        subtitleTextView.setText(currentPlace.getPlaceDesc());
        ImageView myImageView = listItemView.findViewById(R.id.myImage);
        if (currentPlace.hasImage()) {
            myImageView.setImageResource(currentPlace.getItemImage());
        } else {
            myImageView.setVisibility(View.GONE);
        }
        View textContainer = listItemView.findViewById(R.id.place_info_card_view);
        int color = ContextCompat.getColor(getContext(), viewBGColor);
        textContainer.setBackgroundColor(color);
        return listItemView;
    }
}
