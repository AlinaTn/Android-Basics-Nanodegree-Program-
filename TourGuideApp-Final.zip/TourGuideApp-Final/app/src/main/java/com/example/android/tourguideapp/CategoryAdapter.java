package com.example.android.tourguideapp;

import android.content.Context;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.Fragment;

public class CategoryAdapter extends FragmentPagerAdapter {

    static final int NUM_ITEMS = 4;
    private Context mContext;

    public CategoryAdapter(Context context, FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new KyotoFragment();
            case 1:
                return new OsakaFragment();
            case 2:
                return new HiroshimaFragment();
            case 3:
                return new TokyoFragment();
            default:
                return new KyotoFragment();
        }
    }

    @Override
    public int getCount() {
        return NUM_ITEMS;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return mContext.getString(R.string.category_kyoto);
            case 1:
                return mContext.getString(R.string.category_osaka);
            case 2:
                return mContext.getString(R.string.category_hiroshima);
            case 3:
                return mContext.getString(R.string.category_tokyo);
            default:
                return mContext.getString(R.string.category_kyoto);
        }
    }
}

