package com.example.android.inventoryapp1;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.inventoryapp1.data.TiresContract.TiresEntry;

public class TiresCursorAdapter extends CursorAdapter {

    public TiresCursorAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
    }


    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.item_tires, parent, false);
    }


    @Override
    public void bindView(View view, final Context context, Cursor cursor) {
        TextView modelName = view.findViewById(R.id.textView_tires_model);
        TextView modelPrice = view.findViewById(R.id.textView_tires_price);
        TextView modelQuantity = view.findViewById(R.id.textView_model_quantity);
        TextView modelId = view.findViewById(R.id.textView_ID);
        Button sale = view.findViewById(R.id.button_sale);

        final int columnIndex = cursor.getInt(cursor.getColumnIndex(TiresEntry._ID));
        final int quantity = cursor.getInt(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_QUANTITY));

        modelName.setText(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_MODEL_NAME)));
        modelPrice.setText(context.getString(R.string.adapter_price) + String.valueOf(cursor.getInt(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_PRICE))));
        modelQuantity.setText(context.getString(R.string.adapter_quantity) + String.valueOf(quantity));
        modelId.setText(Integer.toString(cursor.getPosition() + 1));

        sale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = ContentUris.withAppendedId(TiresEntry.CONTENT_URI, columnIndex);

                if (quantity == 0) {
                    Toast.makeText(context, R.string.adapter_out_of_stock, Toast.LENGTH_SHORT).show();
                } else {
                    int newQuantity = quantity - 1;

                    if (newQuantity == 0) {
                        Toast.makeText(context, R.string.adapter_out_of_stock, Toast.LENGTH_SHORT).show();
                    }

                    ContentValues contentValues = new ContentValues();
                    contentValues.put(TiresEntry.COLUMN_TIRES_QUANTITY, newQuantity);
                    context.getContentResolver().update(uri, contentValues, null, null);
                }
            }
        });
    }
}
