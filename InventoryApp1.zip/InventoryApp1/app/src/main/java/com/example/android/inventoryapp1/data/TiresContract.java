package com.example.android.inventoryapp1.data;


import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

public class TiresContract {

    public static final String CONTENT_AUTHORITY = "com.example.android.inventoryapp1";
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);
    public static final String PATH_TIRES = "tires";
    private TiresContract() {
    }

    public static final class TiresEntry implements BaseColumns {

        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_TIRES);


        public static final String CONTENT_LIST_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_TIRES;
        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_TIRES;


        public final static String TABLE_NAME = "tires";

        public final static String _ID = BaseColumns._ID;
        public final static String COLUMN_TIRES_MODEL_NAME = "name";
        public final static String COLUMN_TIRES_PRICE = "price";
        public final static String COLUMN_TIRES_QUANTITY = "quantity";
        public final static String COLUMN_TIRES_SIZE = "size";
        public final static String COLUMN_TIRES_WEIGHT = "weight";
        public final static String COLUMN_TIRES_MATERIAL = "material";

        public final static String COLUMN_TIRES_SUPPLIER_NAME = "supplier_name";
        public final static String COLUMN_TIRES_SUPPLIER_PHONE = "supplier_phone";

        public static final int SIZE_Q = 0;
        public static final int SIZE_R = 1;
        public static final int SIZE_S = 2;


        public static final int MATERIAL_RUBBER = 0;
        public static final int MATERIAL_KEVLOR = 1;
        public static final int MATERIAL_SYNTHETIC_CABLE = 2;

        public static boolean isValidSize(int size) {
            return (size == SIZE_Q || size == SIZE_R || size == SIZE_S);
        }

        public static boolean isValidMaterial(int material) {
            return (material == MATERIAL_RUBBER || material == MATERIAL_KEVLOR || material == MATERIAL_SYNTHETIC_CABLE);
        }
    }
}

