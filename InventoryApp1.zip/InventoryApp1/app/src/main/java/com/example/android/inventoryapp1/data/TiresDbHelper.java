package com.example.android.inventoryapp1.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.android.inventoryapp1.data.TiresContract.TiresEntry;


public class TiresDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tires.db";
    private static final int DATABASE_VERSION = 1;


    public TiresDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String TIRES_DATABASE_CREATE = "CREATE TABLE " + TiresEntry.TABLE_NAME + " (" +
                TiresEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                TiresEntry.COLUMN_TIRES_MODEL_NAME + " TEXT NOT NULL ," +
                TiresEntry.COLUMN_TIRES_PRICE + " INTEGER NOT NULL," +
                TiresEntry.COLUMN_TIRES_QUANTITY + " INTEGER NOT NULL DEFAULT 0," +
                TiresEntry.COLUMN_TIRES_SIZE + " INTEGER NOT NULL, " +
                TiresEntry.COLUMN_TIRES_WEIGHT + " INTEGER NOT NULL, " +
                TiresEntry.COLUMN_TIRES_MATERIAL + " INTEGER NOT NULL, " +
                TiresEntry.COLUMN_TIRES_SUPPLIER_NAME + " TEXT NOT NULL ," +
                TiresEntry.COLUMN_TIRES_SUPPLIER_PHONE + " TEXT NOT NULL );";

        sqLiteDatabase.execSQL(TIRES_DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //do nothing for now
    }
}
