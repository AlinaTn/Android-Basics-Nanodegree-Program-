package com.example.android.inventoryapp1;

import android.content.DialogInterface;
import android.widget.Toast;
import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentUris;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


import com.example.android.inventoryapp1.data.TiresContract.TiresEntry;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    public final static int TIRES_LOADER = 0;
    private TiresCursorAdapter tiresCursorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView tiresItemsList = findViewById(R.id.listView_items);
        View emptyView = findViewById(R.id.empty_view);

        tiresCursorAdapter = new TiresCursorAdapter(this, null);

        tiresItemsList.setEmptyView(emptyView);
        tiresItemsList.setAdapter(tiresCursorAdapter);

        tiresItemsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, ItemActivity.class);
                Uri currentPetUri = ContentUris.withAppendedId(TiresEntry.CONTENT_URI, id);
                intent.setData(currentPetUri);
                startActivity(intent);
            }
        });

        getLoaderManager().initLoader(TIRES_LOADER, null, MainActivity.this);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] projection = {
                TiresEntry._ID,
                TiresEntry.COLUMN_TIRES_MODEL_NAME,
                TiresEntry.COLUMN_TIRES_QUANTITY,
                TiresEntry.COLUMN_TIRES_PRICE};

        return new CursorLoader(this,
                TiresEntry.CONTENT_URI,
                projection,
                null,
                null,
                null);
    }


    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        tiresCursorAdapter.swapCursor(cursor);
    }


    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        tiresCursorAdapter.swapCursor(null);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add_tires:
                startActivity(new Intent(MainActivity.this, EditorActivity.class));
                return true;
            case R.id.action_delete_all_tires_items:
                showDeleteConfirmationDialog();
                return true;
            case R.id.action_exit:
                showExitConfirmationDialog();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void showExitConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Exit?");
        builder.setPositiveButton(R.string.alert_yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                finish();
            }
        });
        builder.setNegativeButton(R.string.alert_no, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.alert_all_tires_deletion);
        builder.setPositiveButton(R.string.alert_delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                deleteAllTires();
            }
        });
        builder.setNegativeButton(R.string.alert_cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    private void deleteAllTires() {
        int rowsDeleted = getContentResolver().delete(TiresEntry.CONTENT_URI, null, null);

        if (rowsDeleted == 0) {
            Toast.makeText(this, R.string.toast_deletion_failed, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, R.string.toast_all_tires_deleted, Toast.LENGTH_LONG).show();
        }
    }


    @Override
    public void onBackPressed() {
        showExitConfirmationDialog();
    }
}