package com.example.android.inventoryapp1;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.inventoryapp1.data.TiresContract.TiresEntry;

public class ItemActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    public static final int EXISTING_TIRES_LOADER = 0;
    private TextView model, price, quantity, size, weight, material, supplier, supplierPhone;
    private Button increase, decrease, call;
    private Uri currentTiresUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);

        model = findViewById(R.id.textView_item_model_name);
        price = findViewById(R.id.textView_item_price);
        quantity = findViewById(R.id.textView_item_quantity);
        size = findViewById(R.id.textView_item_size);
        weight = findViewById(R.id.textView_item_weight);
        material = findViewById(R.id.textView_item_material);
        supplier = findViewById(R.id.textView_item_supplier);
        supplierPhone = findViewById(R.id.textView_item_supplier_phone);
        call = findViewById(R.id.button_item_call_supplier);
        increase = findViewById(R.id.button_item_increase);
        decrease = findViewById(R.id.button_item_decrease);

        Intent intent = getIntent();
        currentTiresUri = intent.getData();

        getLoaderManager().initLoader(EXISTING_TIRES_LOADER, null, this);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] projection = {
                TiresEntry._ID,
                TiresEntry.COLUMN_TIRES_PRICE,
                TiresEntry.COLUMN_TIRES_SUPPLIER_PHONE,
                TiresEntry.COLUMN_TIRES_QUANTITY,
                TiresEntry.COLUMN_TIRES_SIZE,
                TiresEntry.COLUMN_TIRES_MODEL_NAME,
                TiresEntry.COLUMN_TIRES_MATERIAL,
                TiresEntry.COLUMN_TIRES_WEIGHT,
                TiresEntry.COLUMN_TIRES_SUPPLIER_NAME};

        return new CursorLoader(this,
                currentTiresUri,
                projection,
                null,
                null,
                null);
    }


    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        if (cursor == null || cursor.getCount() < 1) {
            return;
        }

        if (cursor.moveToFirst()) {
            model.setText(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_MODEL_NAME)));
            setTitle("Model: " + cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_MODEL_NAME)));
            price.setText(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_PRICE)));
            weight.setText(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_WEIGHT)));
            supplier.setText(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_SUPPLIER_NAME)));
            quantity.setText(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_QUANTITY)));

            final String phone = cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_SUPPLIER_PHONE));
            supplierPhone.setText(phone);

            switch (Integer.parseInt(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_MATERIAL)))) {
                case TiresEntry.MATERIAL_RUBBER:
                    material.setText(getResources().getString(R.string.material_rubber));
                    break;
                case TiresEntry.MATERIAL_KEVLOR:
                    material.setText(getResources().getString(R.string.material_kevlor));
                    break;
                case TiresEntry.MATERIAL_SYNTHETIC_CABLE:
                    material.setText(getResources().getString(R.string.material_synthetic_cable));
                    break;
                default:
                    material.setText(R.string.unknown_material);
            }

            switch (Integer.parseInt(cursor.getString(cursor.getColumnIndex(TiresEntry.COLUMN_TIRES_SIZE)))) {
                case TiresEntry.SIZE_Q:
                    size.setText(getResources().getString(R.string.size_Q));
                    break;
                case TiresEntry.SIZE_R:
                    size.setText(getResources().getString(R.string.size_R));
                    break;
                case TiresEntry.SIZE_S:
                    size.setText(getResources().getString(R.string.size_S));
                    break;
                default:
                    size.setText(R.string.unknown_size);
            }

            call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:" + phone));
                    startActivity(intent);
                }
            });

            increase.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    ContentValues contentValues = new ContentValues();
                    contentValues.put(TiresEntry.COLUMN_TIRES_QUANTITY, Integer.parseInt(quantity.getText().toString().trim()) + 1);
                    getContentResolver().update(currentTiresUri, contentValues, null, null);
                }
            });

            decrease.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (Integer.parseInt(quantity.getText().toString().trim()) <= 0) {
                        Toast.makeText(ItemActivity.this, R.string.toast_out_of_stock, Toast.LENGTH_SHORT).show();
                    } else {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(TiresEntry.COLUMN_TIRES_QUANTITY, Integer.parseInt(quantity.getText().toString().trim()) - 1);
                        getContentResolver().update(currentTiresUri, contentValues, null, null);
                    }
                }
            });
        }
    }


    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        //nothing to do
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_item_edit_tires:
                Intent intent = new Intent(ItemActivity.this, EditorActivity.class);
                intent.setData(currentTiresUri);
                currentTiresUri = null;
                startActivity(intent);
                return true;
            case R.id.action_item_delete_tires:
                showDeleteConfirmationDialog();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.alert_confirm_tires_deletion);

        builder.setPositiveButton(R.string.alert_delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                deleteTires();
            }
        });

        builder.setNegativeButton(R.string.alert_cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    private void deleteTires() {
        if (currentTiresUri != null) {
            int rowsDeleted = getContentResolver().delete(currentTiresUri, null, null);

            if (rowsDeleted == 0) {
                Toast.makeText(this, R.string.toast_deletion_failed, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, R.string.toast_deletion_successful, Toast.LENGTH_LONG).show();
            }
        }

        finish();
    }
}
