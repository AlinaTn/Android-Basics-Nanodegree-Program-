package com.example.android.musicalapp;

import java.io.Serializable;

/**
 * {@link Artist} represents an artist who has albums.
 * It contains an artist name, a resource id of the artist image drawable.
 */

public class Artist implements Serializable {

    /**
     * Name of the artist
     */
    private String ArtistName;

    /**
     * Image of the artist
     */
    private int ArtistImage;

    /**
     * Artist constructor.
     *
     * @param artistName  Name of the artist.
     * @param artistImage Resource id of the artist image drawable
     */
    public Artist(String artistName, int artistImage) {
        ArtistName = artistName;
        ArtistImage = artistImage;
    }

    /**
     * Gets the artist name.
     *
     * @return artist name
     */
    public String getArtistName() {
        return ArtistName;
    }

    /**
     * Gets the artist image.
     *
     * @return artist image
     */
    public int getArtistImage() {
        return ArtistImage;
    }

}