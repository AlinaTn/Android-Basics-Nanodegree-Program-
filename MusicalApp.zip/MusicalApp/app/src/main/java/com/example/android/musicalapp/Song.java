package com.example.android.musicalapp;

import java.io.Serializable;

/**
 * {@link Song} represents a song that the user wants to listen to.
 * It contains a song title, the duration of the song in miliseconds,
 * and an artist object.
 */

public class Song implements Serializable {

    /**
     * Title of the song
     */
    private String SongTitle;

    /**
     * Duration of the song in milliseconds
     */
    private int SongDuration;

    /**
     * Album of the song (that contains the artist and the genre as well)
     */
    private Album SongAlbum;

    /**
     * Song constructor.
     *
     * @param songTitle    Title of the song.
     * @param songDuration Duration of the song in miliseconds.
     * @param songAlbum    Album object of the song.
     */
    public Song(String songTitle, int songDuration, Album songAlbum) {
        SongTitle = songTitle;
        SongDuration = songDuration;
        SongAlbum = songAlbum;
    }

    /**
     * Gets the song title.
     *
     * @return song title
     */
    public String getSongTitle() {
        return SongTitle;
    }

    /**
     * Gets the artist name of the song
     *
     * @return artist name
     */
    public String getSongArtistName() {
        return SongAlbum.getAlbumArtistName();
    }

    /**
     * Gets the album title of the song.
     *
     * @return album title
     */
    public String getSongAlbumTitle() {
        return SongAlbum.getAlbumTitle();
    }

    /**
     * Gets the genre name of the song.
     *
     * @return genre name
     */
    public String getSongAlbumGenre() {
        return SongAlbum.getAlbumGenreName();
    }

    /**
     * Gets the album cover resource id of the song.
     *
     * @return album cover resource id
     */
    public int getmSongAlbumCover() {
        return SongAlbum.getAlbumCover();
    }

    /**
     * Gets the song duration.
     *
     * @return Song duration in miliseconds
     */
    public int getSongDuration() {
        return SongDuration;
    }

    /**
     * Gets the album of the song
     *
     * @return Album object of the song
     */
    public Album getSongAlbum() {
        return SongAlbum;
    }

    /**
     * Gets the genre of the song
     *
     * @return Genre object of the song
     */
    public Genre getSongGenre() {
        return SongAlbum.getAlbumGenre();
    }

}


