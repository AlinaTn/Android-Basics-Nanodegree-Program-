package com.example.android.musicalapp;

import java.io.Serializable;

/**
 * {@link Album} represents an album that the user wants to listen to.
 * It contains an album title, a resource id of the album cover drawable,
 * the release year of the album, an artist object and a genre object.
 */

public class Album implements Serializable {

    /**
     * Title of the album
     */
    private String AlbumTitle;

    /**
     * Image of the album cover
     */
    private int AlbumCover;

    /**
     * Year of the album release
     */
    private int AlbumYear;

    /**
     * Artist object of the album
     */
    private Artist AlbumArtist;

    /**
     * Genre object of the album
     */
    private Genre AlbumGenre;

    /**
     * Album constructor.
     *
     * @param albumTitle  Title of the album.
     * @param albumCover  Resource id of the album cover drawable.
     * @param albumYear   Release year of the album.
     * @param albumArtist Artist object index of the album.
     * @param albumGenre  Genre object index of the album.
     */
    public Album(String albumTitle, int albumCover, int albumYear, Artist albumArtist, Genre albumGenre) {
        AlbumTitle = albumTitle;
        AlbumYear = albumYear;
        AlbumCover = albumCover;
        AlbumArtist = albumArtist;
        AlbumGenre = albumGenre;
    }

    /**
     * Gets the title of the album
     *
     * @return album title
     */
    public String getAlbumTitle() {
        return AlbumTitle;
    }

    /**
     * Gets the release year of the album
     *
     * @return elease year
     */
    public int getAlbumYear() {
        return AlbumYear;
    }

    /**
     * Gets the resource id of the Album cover
     *
     * @return album cover res id
     */
    public int getAlbumCover() {
        return AlbumCover;
    }

    /**
     * Gets the artist object of the album
     *
     * @return artist object
     */
    public Artist getAlbumArtist() {
        return AlbumArtist;
    }

    /**
     * Gets the artist name of the album.
     *
     * @return artist name
     */
    public String getAlbumArtistName() {
        return AlbumArtist.getArtistName();
    }

    /**
     * Gets the genre object of the album
     *
     * @return genre naobjectme
     */
    public Genre getAlbumGenre() {
        return AlbumGenre;
    }

    /**
     * Gets the genre name of the album
     *
     * @return genre name
     */
    public String getAlbumGenreName() {
        return AlbumGenre.getGenreName();
    }
}