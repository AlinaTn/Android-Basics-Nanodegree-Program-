package com.example.android.musicalapp;

import java.io.Serializable;

/**
 * {@link Genre} represents a genre.
 * It contains a genre name, a resource id of the genre icon drawable.
 */

public class Genre implements Serializable {

    /**
     * Genre of the song or album of the artist
     */
    private String GenreName;

    /**
     * Image of the genre icon
     */
    private int GenreIcon;

    /**
     * Genre constructor.
     *
     * @param genreName Name of the genre.
     * @param genreIcon Resource id of the genre drawable.
     */
    public Genre(String genreName, int genreIcon) {
        GenreName = genreName;
        GenreIcon = genreIcon;
    }

    /**
     * Gets the genre name.
     *
     * @return genre name
     */
    public String getGenreName() {
        return GenreName;
    }

    /**
     * Gets the genre icon.
     *
     * @return genre icon
     */
    public int getGenreIcon() {
        return GenreIcon;
    }
}

