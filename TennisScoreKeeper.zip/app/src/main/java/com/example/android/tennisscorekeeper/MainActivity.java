package com.example.android.tennisscorekeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int pointsForPlayer1 = 0;
    int gamesForPlayer1 = 0;
    int setsForPlayer1 = 0;
    int pointsForPlayer2 = 0;
    int gamesForPlayer2 = 0;
    int setsForPlayer2 = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addPointsForPlayer1(View v) {
        pointsForPlayer1 = pointsForPlayer1 + 1;
        displayPointsForPlayer1(pointsForPlayer1);
    }

    public void addGamesForPlayer1(View v) {
        gamesForPlayer1 = gamesForPlayer1 + 1;
        displayGamesForPlayer1(gamesForPlayer1);
    }

    public void addSetsForPlayer1(View v) {
        setsForPlayer1 = setsForPlayer1 + 1;
        displaySetsForPlayer1(setsForPlayer1);
    }

    public void addPointsForPlayer2(View v) {
        pointsForPlayer2 = pointsForPlayer2 + 1;
        displayPointsForPlayer2(pointsForPlayer2);
    }

    public void addGamesForPlayer2(View v) {
        gamesForPlayer2 = gamesForPlayer2 + 1;
        displayGamesForPlayer2(gamesForPlayer2);
    }

    public void addSetsForPlayer2(View v) {
        setsForPlayer2 = setsForPlayer2 + 1;
        displaySetsForPlayer2(setsForPlayer2);
    }

    /**
     * Resets the score for both players back to zero.
     */
    public void resetGame(View v) {
        pointsForPlayer1 = 0;
        gamesForPlayer1 = 0;
        setsForPlayer1 = 0;
        pointsForPlayer2 = 0;
        gamesForPlayer2 = 0;
        setsForPlayer2 = 0;
        displayPointsForPlayer1(pointsForPlayer1);
        displayGamesForPlayer1(gamesForPlayer1);
        displaySetsForPlayer1(setsForPlayer1);
        displayPointsForPlayer2(pointsForPlayer2);
        displayGamesForPlayer2(gamesForPlayer2);
        displaySetsForPlayer2(setsForPlayer2);
    }

    /**
     * Displays the given score for player 1
     */
    public void displayPointsForPlayer1(int points) {
        TextView scoreView = (TextView) findViewById(R.id.player_1_points);
        scoreView.setText(String.valueOf(points));
    }

    public void displayGamesForPlayer1(int games) {
        TextView scoreView = (TextView) findViewById(R.id.player_1_games);
        scoreView.setText(String.valueOf(games));
    }

    public void displaySetsForPlayer1(int sets) {
        TextView scoreView = (TextView) findViewById(R.id.player_1_sets);
        scoreView.setText(String.valueOf(sets));
    }

    /**
     * Displays the given score for player 2.
     */
    public void displayPointsForPlayer2(int points) {
        TextView scoreView = (TextView) findViewById(R.id.player_2_points);
        scoreView.setText(String.valueOf(points));
    }

    public void displayGamesForPlayer2(int games) {
        TextView scoreView = (TextView) findViewById(R.id.player_2_games);
        scoreView.setText(String.valueOf(games));
    }

    public void displaySetsForPlayer2(int sets) {
        TextView scoreView = (TextView) findViewById(R.id.player_2_sets);
        scoreView.setText(String.valueOf(sets));
    }
}