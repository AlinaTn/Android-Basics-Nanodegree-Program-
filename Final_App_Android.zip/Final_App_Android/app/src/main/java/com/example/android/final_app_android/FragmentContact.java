package com.example.android.final_app_android;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Alina on 24.05.2018.
 */

public class FragmentContact extends android.support.v4.app.Fragment {
    View v;
    private RecyclerView myrecyclerview;
    private List<Contact>lstContact;

    public FragmentContact() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.contact_fragment,container,false);
        myrecyclerview=(RecyclerView) v.findViewById(R.id.contact_recyclerView);
        RecyclerViewAdapter recyclerAdapter= new RecyclerViewAdapter(getContext(),lstContact);
        myrecyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        myrecyclerview.setAdapter(recyclerAdapter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lstContact=new ArrayList<>();
        lstContact.add(new Contact("Maria M","(+40)0745789121",R.drawable.contact_image));
        lstContact.add(new Contact("Miruna T","(+40)0757934257",R.drawable.contact_image));
        lstContact.add(new Contact("Cristina A","(+40)0747869325",R.drawable.contact_image));
        lstContact.add(new Contact("Ioana C","(+40)0746573275",R.drawable.contact_image));
        lstContact.add(new Contact("Carolina","(+40)0747644789",R.drawable.contact_image));
        lstContact.add(new Contact("Karina","(+40)0741586538",R.drawable.contact_image));
        lstContact.add(new Contact("Oana B","(+40)07425789136",R.drawable.contact_image));
        lstContact.add(new Contact("Cosmin","(+40)0743678292",R.drawable.contact_image));
        lstContact.add(new Contact("Ovidiu","(+40)0753768394",R.drawable.contact_image));
        lstContact.add(new Contact("Mihaela","(+40)0769832575",R.drawable.contact_image));
        lstContact.add(new Contact("Alina","(+40)0749573219",R.drawable.contact_image));

    }
}
