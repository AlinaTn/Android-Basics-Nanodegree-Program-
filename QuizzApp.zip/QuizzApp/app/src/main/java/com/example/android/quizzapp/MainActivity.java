package com.example.android.quizzapp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void checkAnswers(View view) {
        EditText questionOneAnswerEditText = (EditText) findViewById(R.id.question_one_answer);
        String questionOneAnswer = questionOneAnswerEditText.getText().toString();
        boolean isQuestionOneAnswer = questionOneAnswer.equalsIgnoreCase("The Seine") || questionOneAnswer.equalsIgnoreCase("The Seine ");

        CheckBox questionTwoAnswerOneCheckBox = (CheckBox) findViewById(R.id.question_two_answer_one);
        boolean isQuestionTwoAnswerOne = questionTwoAnswerOneCheckBox.isChecked();
        CheckBox questionTwoAnswerTwoCheckBox = (CheckBox) findViewById(R.id.question_two_answer_two);
        boolean isQuestionTwoAnswerTwo = questionTwoAnswerTwoCheckBox.isChecked();
        CheckBox questionTwoAnswerThreeCheckBox = (CheckBox) findViewById(R.id.question_two_answer_three);
        boolean isQuestionTwoAnswerThree = questionTwoAnswerThreeCheckBox.isChecked();
        CheckBox questionTwoAnswerFourCheckBox = (CheckBox) findViewById(R.id.question_two_answer_four);
        boolean isQuestionTwoAnswerFour = questionTwoAnswerFourCheckBox.isChecked();
        boolean isQuestionTwoTotal = isQuestionTwoAnswerOne && isQuestionTwoAnswerTwo && !isQuestionTwoAnswerThree && isQuestionTwoAnswerFour;

        RadioButton questionThreeAnswerThreeRadioButton = (RadioButton) findViewById(R.id.question_three_answer_three);
        boolean isQuestionThreeAnswerThree = questionThreeAnswerThreeRadioButton.isChecked();

        CheckBox questionFourAnswerOneCheckBox = (CheckBox) findViewById(R.id.question_four_answer_one);
        boolean isQuestionFourAnswerOne = questionFourAnswerOneCheckBox.isChecked();
        CheckBox questionFourAnswerTwoCheckBox = (CheckBox) findViewById(R.id.question_four_answer_two);
        boolean isQuestionFourAnswerTwo = questionFourAnswerTwoCheckBox.isChecked();
        CheckBox questionFourAnswerThreeCheckBox = (CheckBox) findViewById(R.id.question_four_answer_three);
        boolean isQuestionFourAnswerThree = questionFourAnswerThreeCheckBox.isChecked();
        CheckBox questionFourAnswerFourCheckBox = (CheckBox) findViewById(R.id.question_four_answer_four);
        boolean isQuestionFourAnswerFour = questionFourAnswerFourCheckBox.isChecked();
        boolean isQuestionFourTotal = isQuestionFourAnswerOne && isQuestionFourAnswerTwo && !isQuestionFourAnswerThree && !isQuestionFourAnswerFour;

        RadioButton questionFiveAnswerThreeRadioButton = (RadioButton) findViewById(R.id.question_five_answer_three);
        boolean isQuestionFiveAnswerThree = questionFiveAnswerThreeRadioButton.isChecked();

        EditText questionSixAnswerEditText = (EditText) findViewById(R.id.question_six_answer);
        String questionSixAnswer = questionSixAnswerEditText.getText().toString();
        boolean isQuestionSixAnswer = questionSixAnswer.equalsIgnoreCase("Rome") || questionSixAnswer.equalsIgnoreCase("Rome ");

        Context context = getApplicationContext();
        CharSequence text = createAnswerSummary(isQuestionOneAnswer, isQuestionTwoTotal, isQuestionThreeAnswerThree, isQuestionFourTotal, isQuestionFiveAnswerThree, isQuestionSixAnswer);
        int duration = Toast.LENGTH_LONG;
        Toast finalResult = Toast.makeText(context, text, duration);
        finalResult.show();
    }

    public String translateBoolean(boolean booleanToString) {
        String translation = booleanToString ? getString(R.string.boolean_true) : getString(R.string.boolean_false);
        return translation;
    }

    public String createAnswerSummary(boolean isQuestionOneAnswer, boolean isQuestionTwoTotal, boolean isQuestionThreeAnswerThree, boolean isQuestionFourTotal, boolean isQuestionFiveAnswerThree, boolean isQuestionSixAnswer) {
        int counter = 0;

        if (isQuestionOneAnswer) {
            counter += 1;
        }

        if (isQuestionTwoTotal) {
            counter += 1;
        }

        if (isQuestionThreeAnswerThree) {
            counter += 1;
        }

        if (isQuestionFourTotal) {
            counter += 1;
        }

        if (isQuestionFiveAnswerThree) {
            counter += 1;
        }

        if (isQuestionSixAnswer) {
            counter += 1;
        }
        String quizResultsMessage = getString(R.string.counter, counter);
        quizResultsMessage += "\n\n" + getString(R.string.answer_summary_question_one, translateBoolean(isQuestionOneAnswer));
        quizResultsMessage += "\n" + getString(R.string.answer_summary_question_two, translateBoolean(isQuestionTwoTotal));
        quizResultsMessage += "\n" + getString(R.string.answer_summary_question_three, translateBoolean(isQuestionThreeAnswerThree));
        quizResultsMessage += "\n" + getString(R.string.answer_summary_question_four, translateBoolean(isQuestionFourTotal));
        quizResultsMessage += "\n" + getString(R.string.answer_summary_question_five, translateBoolean(isQuestionFiveAnswerThree));
        quizResultsMessage += "\n" + getString(R.string.answer_summary_question_six, translateBoolean(isQuestionSixAnswer));
        quizResultsMessage += "\n\n" + getString(R.string.thank_you);
        {
            if (counter >= 3) {
                quizResultsMessage += "\n\n" + getString(R.string.you_win);
            } else if (counter < 2) {
                quizResultsMessage += "\n\n" + getString(R.string.you_lose);
            }
            return quizResultsMessage;
        }

    }
}



