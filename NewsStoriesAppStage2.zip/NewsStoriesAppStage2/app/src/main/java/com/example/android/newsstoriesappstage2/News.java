package com.example.android.newsstoriesappstage2;

import java.util.Date;


public class News {

    private String WebTitle;
    private String SectionName;
    private String AuthorName;
    private Date PublicationDate;
    private String Url;

    /**
     * Create a News object.
     *
     * @param webTitle        is the web title of the news
     * @param sectionName     is the section name of the news
     * @param authorName      is the author name of the news
     * @param publicationDate is the publication date of the news
     * @param url             is the website URL to find more details about the news
     */
    public News(String webTitle, String sectionName, String authorName, Date publicationDate, String url) {
        WebTitle = webTitle;
        SectionName = sectionName;
        AuthorName = authorName;
        PublicationDate = publicationDate;
        Url = url;
    }

    public String getWebTitle() {
        return WebTitle;
    }

    public String getSectionName() {
        return SectionName;
    }

    public String getAuthorName() {
        return AuthorName;
    }

    public Date getPublicationDate() {
        return PublicationDate;
    }

    public String getUrl() {
        return Url;
    }
}
